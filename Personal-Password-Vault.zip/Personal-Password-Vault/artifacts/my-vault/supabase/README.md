# Supabase setup for My Vault

1. In the Supabase SQL Editor, run `schema.sql` once.
2. In Supabase Authentication, enable email/password sign-in.
3. Configure the site's URL and allowed redirect URLs for the exact My Vault preview URL used for testing and the published app URL when it is published.
4. Sign in to My Vault and keep using the existing master password to unlock the encrypted vault. The account password and master password are separate.

The browser client uses only the project's anon/publishable key. The `vault_envelopes` table is protected by row-level security so an authenticated user can access only their own encrypted envelope. Never put a Supabase `service_role` key in this app.
