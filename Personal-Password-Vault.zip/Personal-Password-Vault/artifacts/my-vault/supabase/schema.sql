-- Run this once in the SQL Editor for the Supabase project used by My Vault.
-- The cloud stores only the app's already-encrypted vault envelope.

create table if not exists public.vault_envelopes (
  user_id uuid primary key references auth.users (id) on delete cascade,
  envelope jsonb not null,
  revision integer not null default 1 check (revision > 0),
  updated_at timestamptz not null default now()
);

alter table public.vault_envelopes enable row level security;

revoke all on table public.vault_envelopes from anon, public;
grant select, insert, update on table public.vault_envelopes to authenticated;

drop policy if exists "Users can read their own vault envelope" on public.vault_envelopes;
create policy "Users can read their own vault envelope"
  on public.vault_envelopes for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Users can create their own vault envelope" on public.vault_envelopes;
create policy "Users can create their own vault envelope"
  on public.vault_envelopes for insert to authenticated
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users can update their own vault envelope" on public.vault_envelopes;
create policy "Users can update their own vault envelope"
  on public.vault_envelopes for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
