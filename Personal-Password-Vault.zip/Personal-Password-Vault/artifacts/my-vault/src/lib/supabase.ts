import { createClient } from '@supabase/supabase-js';
import { isEnvelope, type VaultEnvelope } from '../vault';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const cloudSyncConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase = cloudSyncConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
      },
    })
  : null;

export type CloudVault = {
  envelope: VaultEnvelope;
  revision: number;
  updatedAt: string;
};

function requireSupabase() {
  if (!supabase) throw new Error('Cloud sync is not configured for this app.');
  return supabase;
}

export async function readCloudVault(userId: string): Promise<CloudVault | null> {
  const { data, error } = await requireSupabase()
    .from('vault_envelopes')
    .select('envelope, revision, updated_at')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  if (!data) return null;

  if (!isEnvelope(data.envelope) || !Number.isInteger(data.revision) || data.revision < 1) {
    throw new Error('The cloud vault record has an unsupported format. Your local copy was not changed.');
  }
  return {
    envelope: data.envelope,
    revision: data.revision,
    updatedAt: typeof data.updated_at === 'string' ? data.updated_at : '',
  };
}

export async function createCloudVault(userId: string, envelope: VaultEnvelope): Promise<number> {
  const { data, error } = await requireSupabase()
    .from('vault_envelopes')
    .insert({ user_id: userId, envelope })
    .select('revision')
    .single();
  if (error) throw error;
  return data.revision as number;
}

export async function updateCloudVault(
  userId: string,
  expectedRevision: number,
  envelope: VaultEnvelope,
): Promise<number | null> {
  const { data, error } = await requireSupabase()
    .from('vault_envelopes')
    .update({
      envelope,
      revision: expectedRevision + 1,
      updated_at: new Date().toISOString(),
    })
    .eq('user_id', userId)
    .eq('revision', expectedRevision)
    .select('revision')
    .maybeSingle();
  if (error) throw error;
  return data ? (data.revision as number) : null;
}
