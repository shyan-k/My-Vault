import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import {
  ArrowDownToLine, ArrowUpFromLine, Check, Cloud, Copy, Eye, EyeOff,
  KeyRound, LockKeyhole, LogOut, Plus, Search, ShieldCheck, X, Pencil, Trash2, Globe2,
} from 'lucide-react';
import type { Session } from '@supabase/supabase-js';
import {
  createEntry, deriveVaultKey, envelopeSalt, isEnvelope, openEntriesWithKey, readEnvelope, sealEntriesWithKey,
  unlockEnvelope, writeEnvelope, type Category, type VaultEntry, type VaultEnvelope,
} from './vault';
import { Brand } from './components/Brand';
import { LockScreen } from './components/LockScreen';
import { ThemeToggle, type ThemeMode } from './components/ThemeToggle';
import { AccountDialog, type AccountCredentials, type AccountMode } from './components/AccountDialog';
import { SyncConflictDialog } from './components/SyncConflictDialog';
import { cloudSyncConfigured, createCloudVault, readCloudVault, supabase, updateCloudVault, type CloudVault } from './lib/supabase';

type Screen = 'loading' | 'create' | 'unlock' | 'vault' | 'storage-error';
type Notice = { text: string; kind?: 'error' | 'success' };
type Draft = Omit<VaultEntry, 'id' | 'createdAt' | 'updatedAt'>;
type SyncConflict = { local: VaultEnvelope | null; remote: CloudVault };
const THEME_STORAGE_KEY = 'my-vault-theme';
const blankDraft: Draft = { name: '', category: 'Other', username: '', password: '', website: '', notes: '' };

function sameEnvelope(left: VaultEnvelope | null, right: VaultEnvelope | null): boolean {
  return left === right || Boolean(left && right
    && left.format === right.format
    && left.version === right.version
    && left.salt === right.salt
    && left.iv === right.iv
    && left.ciphertext === right.ciphertext);
}

function isUniqueViolation(error: unknown): boolean {
  return Boolean(error && typeof error === 'object' && 'code' in error && (error as { code?: unknown }).code === '23505');
}

function downloadEnvelope(envelope: VaultEnvelope, label: string) {
  const blob = new Blob([JSON.stringify(envelope, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${label}-${new Date().toISOString().slice(0, 10)}.json`;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function readThemePreference(): ThemeMode {
  try {
    return localStorage.getItem(THEME_STORAGE_KEY) === 'light' ? 'light' : 'dark';
  } catch {
    return 'dark';
  }
}

function App() {
  const [screen, setScreen] = useState<Screen>('loading');
  const [theme, setTheme] = useState<ThemeMode>(readThemePreference);
  const [envelope, setEnvelope] = useState<VaultEnvelope | null>(null);
  const [entries, setEntries] = useState<VaultEntry[]>([]);
  const [key, setKey] = useState<CryptoKey | null>(null);
  const [salt, setSalt] = useState<Uint8Array | null>(null);
  const [masterPassword, setMasterPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState<Notice | null>(null);
  const [filter, setFilter] = useState<'All' | Category>('All');
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<VaultEntry | null | 'new'>(null);
  const [draft, setDraft] = useState<Draft>(blankDraft);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [showMaster, setShowMaster] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [bootComplete, setBootComplete] = useState(false);
  const [syncStatus, setSyncStatus] = useState('Local only — sign in to sync across devices.');
  const [syncConflict, setSyncConflict] = useState<SyncConflict | null>(null);
  const [showSyncConflict, setShowSyncConflict] = useState(false);
  const [syncBusy, setSyncBusy] = useState(false);
  const [accountDialogOpen, setAccountDialogOpen] = useState(false);
  const [accountMode, setAccountMode] = useState<AccountMode>('sign-in');
  const [accountBusy, setAccountBusy] = useState(false);
  const [accountError, setAccountError] = useState('');
  const [accountMessage, setAccountMessage] = useState('');
  const importRef = useRef<HTMLInputElement>(null);
  const cloudRevisionRef = useRef<number | null>(null);
  const lastSyncedEnvelopeRef = useRef<VaultEnvelope | null>(null);
  const bootStartedRef = useRef(false);
  const activeUserIdRef = useRef<string | null | undefined>(undefined);
  const cloudCheckInProgressRef = useRef(false);
  const syncConflictRef = useRef<SyncConflict | null>(null);

  const updateCloudRevision = (revision: number | null) => {
    cloudRevisionRef.current = revision;
  };

  const updateSyncConflict = (conflict: SyncConflict | null) => {
    syncConflictRef.current = conflict;
    setSyncConflict(conflict);
  };

  const reconcileAccount = async (currentSession: Session, localCopy: VaultEnvelope | null): Promise<VaultEnvelope | null> => {
    if (!supabase) return localCopy;
    updateCloudRevision(null);
    try {
      let remote = await readCloudVault(currentSession.user.id);
      if (!remote && localCopy) {
        try {
          const revision = await createCloudVault(currentSession.user.id, localCopy);
          updateCloudRevision(revision);
          lastSyncedEnvelopeRef.current = localCopy;
          updateSyncConflict(null);
          setSyncStatus('Your encrypted vault is synced to this account.');
          return localCopy;
        } catch (caught) {
          if (!isUniqueViolation(caught)) throw caught;
          remote = await readCloudVault(currentSession.user.id);
        }
      }

      if (!remote) {
        lastSyncedEnvelopeRef.current = null;
        setSyncStatus('Account connected — create or unlock a vault to sync it.');
        return null;
      }

      updateCloudRevision(remote.revision);
      if (!localCopy) {
        await writeEnvelope(remote.envelope);
        lastSyncedEnvelopeRef.current = remote.envelope;
        updateSyncConflict(null);
        setSyncStatus('Encrypted cloud vault found. Unlock it with its existing master password.');
        return remote.envelope;
      }
      if (sameEnvelope(localCopy, remote.envelope)) {
        lastSyncedEnvelopeRef.current = localCopy;
        updateSyncConflict(null);
        setSyncStatus('Your encrypted vault is synced to this account.');
        return localCopy;
      }

      lastSyncedEnvelopeRef.current = null;
      updateSyncConflict({ local: localCopy, remote });
      setShowSyncConflict(true);
      setSyncStatus('Two different copies found. Neither has been replaced.');
      return localCopy;
    } catch {
      setSyncStatus('Cloud unavailable. If setup is incomplete, run the included Supabase schema.sql. Your local vault is unchanged.');
      return localCopy;
    }
  };

  const syncLocalEnvelope = async (currentSession: Session, nextEnvelope: VaultEnvelope): Promise<boolean> => {
    if (!supabase) return false;
    if (syncConflictRef.current) {
      setSyncStatus('Two different copies found. Resolve the sync conflict before syncing changes.');
      return false;
    }
    try {
      let revision = cloudRevisionRef.current;
      if (revision === null) {
        try {
          revision = await createCloudVault(currentSession.user.id, nextEnvelope);
        } catch (caught) {
          if (!isUniqueViolation(caught)) throw caught;
          const remote = await readCloudVault(currentSession.user.id);
          if (remote) {
            updateCloudRevision(remote.revision);
            updateSyncConflict({ local: nextEnvelope, remote });
            setShowSyncConflict(true);
            setSyncStatus('A cloud copy appeared while syncing. Neither copy was replaced.');
          }
          return false;
        }
      } else {
        const nextRevision = await updateCloudVault(currentSession.user.id, revision, nextEnvelope);
        if (nextRevision === null) {
          const remote = await readCloudVault(currentSession.user.id);
          if (remote) {
            updateCloudRevision(remote.revision);
            updateSyncConflict({ local: nextEnvelope, remote });
            setShowSyncConflict(true);
            setSyncStatus('Another device changed the cloud copy. Neither copy was replaced.');
          }
          return false;
        }
        revision = nextRevision;
      }
      updateCloudRevision(revision);
      lastSyncedEnvelopeRef.current = nextEnvelope;
      updateSyncConflict(null);
      setSyncStatus('Your encrypted vault is synced to this account.');
      return true;
    } catch {
      setSyncStatus('Saved here. Check Supabase setup or run the included schema.sql; your local copy is safe.');
      return false;
    }
  };

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    root.style.colorScheme = theme;
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // Theme selection still works for this session when browser storage is unavailable.
    }
    document.querySelector<HTMLMetaElement>('meta[name="theme-color"]')?.setAttribute(
      'content',
      theme === 'dark' ? '#101712' : '#f4f2e9',
    );
  }, [theme]);

  useEffect(() => {
    let alive = true;
    if (!supabase) {
      setAuthReady(true);
      return () => { alive = false; };
    }
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!alive) return;
      setSession(nextSession);
      setAuthReady(true);
    });
    void supabase.auth.getSession().then(({ data, error: authError }) => {
      if (!alive) return;
      if (authError) setSyncStatus('Could not check the cloud account. The local vault is still available.');
      setSession(data.session);
      setAuthReady(true);
    }).catch(() => {
      if (alive) {
        setSyncStatus('Could not check the cloud account. The local vault is still available.');
        setAuthReady(true);
      }
    });
    return () => { alive = false; subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (!authReady) return undefined;
    const currentUserId = session?.user.id ?? null;

    if (!bootStartedRef.current) {
      bootStartedRef.current = true;
      activeUserIdRef.current = currentUserId;
      let alive = true;
      void (async () => {
        let saved: VaultEnvelope | null;
        try {
          saved = await readEnvelope();
        } catch {
          if (alive) {
            setError('Local encrypted storage could not be opened. Your existing data was not changed.');
            setScreen('storage-error');
            setBootComplete(true);
          }
          return;
        }
        if (!alive) return;
        setEnvelope(saved);
        if (saved) setScreen('unlock');
        if (session && cloudSyncConfigured) saved = await reconcileAccount(session, saved);
        if (!alive) return;
        setEnvelope(saved);
        setScreen(saved ? 'unlock' : 'create');
        setBootComplete(true);
      })();
      return () => { alive = false; };
    }

    if (activeUserIdRef.current === currentUserId) return undefined;
    activeUserIdRef.current = currentUserId;
    if (!currentUserId || !session) {
      updateCloudRevision(null);
      lastSyncedEnvelopeRef.current = null;
      updateSyncConflict(null);
      setShowSyncConflict(false);
      setSyncStatus('Local only — sign in to sync across devices.');
      return undefined;
    }

    let alive = true;
    void (async () => {
      try {
        const localCopy = await readEnvelope();
        if (!alive) return;
        setEnvelope(localCopy);
        const reconciled = await reconcileAccount(session, localCopy);
        if (!alive) return;
        setEnvelope(reconciled);
        if (!localCopy && reconciled) setScreen('unlock');
      } catch {
        if (alive) setSyncStatus('Cloud connection failed. Your local vault is unchanged.');
      }
    })();
    return () => { alive = false; };
  }, [authReady, session?.user.id]);

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      if (import.meta.env.DEV) {
        void navigator.serviceWorker.getRegistrations()
          .then((registrations) => Promise.all(registrations.map((registration) => registration.unregister())))
          .catch(() => undefined);
        void caches.keys()
          .then((keys) => Promise.all(keys.filter((name) => name.startsWith('my-vault-shell-')).map((name) => caches.delete(name))))
          .catch(() => undefined);
      } else {
        void navigator.serviceWorker.register(`${import.meta.env.BASE_URL}service-worker.js`).catch(() => undefined);
      }
    }
    const installHandler = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', installHandler);
    return () => { window.removeEventListener('beforeinstallprompt', installHandler); };
  }, []);

  useEffect(() => {
    if (!bootComplete || !session || !supabase) return undefined;
    let alive = true;
    const refreshCloudCopy = async () => {
      if (cloudCheckInProgressRef.current) return;
      cloudCheckInProgressRef.current = true;
      try {
        const remote = await readCloudVault(session.user.id);
        if (!alive) return;
        if (!remote) {
          if (envelope && !editing && !syncConflictRef.current) {
            updateCloudRevision(null);
            await syncLocalEnvelope(session, envelope);
          }
          return;
        }
        if (remote.revision === cloudRevisionRef.current) {
          if (envelope && !editing && !syncConflictRef.current
            && !sameEnvelope(envelope, lastSyncedEnvelopeRef.current)) {
            await syncLocalEnvelope(session, envelope);
          }
          return;
        }
        if (!envelope) {
          await writeEnvelope(remote.envelope);
          if (!alive) return;
          setEnvelope(remote.envelope);
          setScreen('unlock');
          updateCloudRevision(remote.revision);
          lastSyncedEnvelopeRef.current = remote.envelope;
          setSyncStatus('Encrypted cloud vault found. Unlock it with its existing master password.');
          return;
        }
        if (sameEnvelope(envelope, remote.envelope)) {
          updateCloudRevision(remote.revision);
          lastSyncedEnvelopeRef.current = remote.envelope;
          return;
        }
        if (syncConflictRef.current) {
          updateCloudRevision(remote.revision);
          updateSyncConflict({ local: envelope, remote });
          setSyncStatus('Two different copies found. Neither has been replaced.');
          return;
        }
        if (key && !editing && sameEnvelope(envelope, lastSyncedEnvelopeRef.current)) {
          try {
            const remoteEntries = await openEntriesWithKey(remote.envelope, key);
            await writeEnvelope(remote.envelope);
            if (!alive) return;
            setEnvelope(remote.envelope);
            setEntries(remoteEntries);
            updateCloudRevision(remote.revision);
            lastSyncedEnvelopeRef.current = remote.envelope;
            setSyncStatus('Updated from your other device.');
            return;
          } catch {
            // A different master key or invalid cloud copy needs explicit conflict handling.
          }
        }
        updateCloudRevision(remote.revision);
        updateSyncConflict({ local: envelope, remote });
        setShowSyncConflict(true);
        setSyncStatus('Another device changed the cloud copy. Neither copy was replaced.');
      } catch {
        if (alive) setSyncStatus('Cloud check failed. If setup is incomplete, run the included schema.sql. Your local vault is unchanged.');
      } finally {
        cloudCheckInProgressRef.current = false;
      }
    };
    const onFocus = () => { void refreshCloudCopy(); };
    void refreshCloudCopy();
    const timer = window.setInterval(() => { void refreshCloudCopy(); }, 20000);
    window.addEventListener('focus', onFocus);
    return () => {
      alive = false;
      window.clearInterval(timer);
      window.removeEventListener('focus', onFocus);
    };
  }, [bootComplete, session?.user.id, envelope, key, editing]);

  useEffect(() => {
    if (!notice) return undefined;
    const timer = window.setTimeout(() => setNotice(null), 3000);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const sortedEntries = useMemo(() => entries
    .filter((entry) => filter === 'All' || entry.category === filter)
    .filter((entry) => `${entry.name} ${entry.category} ${entry.username} ${entry.website} ${entry.notes}`.toLowerCase().includes(search.toLowerCase().trim()))
    .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })), [entries, filter, search]);

  const persistEntries = async (updated: VaultEntry[]): Promise<boolean | null> => {
    if (!key || !salt) throw new Error('Vault is locked. Unlock it before making changes.');
    const sealed = await sealEntriesWithKey(updated, key, salt);
    await writeEnvelope(sealed);
    setEnvelope(sealed);
    setEntries(updated);
    if (syncConflictRef.current) {
      updateSyncConflict({ ...syncConflictRef.current, local: sealed });
      setSyncStatus('Local changes are saved. Resolve the cloud conflict before syncing them.');
      return false;
    }
    return session ? syncLocalEnvelope(session, sealed) : null;
  };

  const openAccountDialog = () => {
    setAccountError('');
    setAccountMessage('');
    setAccountMode('sign-in');
    setAccountDialogOpen(true);
  };

  const submitAccountForm = async ({ email, password }: AccountCredentials) => {
    if (!supabase) {
      setAccountError('Cloud sync is not configured for this app.');
      return;
    }
    setAccountBusy(true);
    setAccountError('');
    setAccountMessage('');
    try {
      if (accountMode === 'sign-up') {
        const { data, error: authError } = await supabase.auth.signUp({ email, password });
        if (authError) throw authError;
        setAccountMessage(data.session
          ? 'Account created. Connecting your encrypted vault…'
          : 'Check your email to confirm your account, then return here to sign in.');
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
        if (authError) throw authError;
        setAccountMessage('Signed in. Checking your encrypted cloud vault…');
      }
    } catch (caught) {
      setAccountError(caught instanceof Error ? caught.message : 'The account request could not be completed.');
    } finally {
      setAccountBusy(false);
    }
  };

  const signOutAccount = async () => {
    if (!supabase) return;
    setAccountBusy(true);
    setAccountError('');
    try {
      const { error: authError } = await supabase.auth.signOut();
      if (authError) throw authError;
      setAccountDialogOpen(false);
      setNotice({ text: 'Signed out. Your local vault and cloud copy remain saved.' });
    } catch (caught) {
      setAccountError(caught instanceof Error ? caught.message : 'Could not sign out.');
    } finally {
      setAccountBusy(false);
    }
  };

  const keepLocalCopy = async () => {
    if (!session || !syncConflict || !supabase) return;
    const localCopy = envelope ?? syncConflict.local;
    if (!localCopy) return;
    if (!window.confirm('My Vault will download an encrypted backup of the current cloud copy, then replace it with this device’s copy. Continue?')) return;
    downloadEnvelope(syncConflict.remote.envelope, 'my-vault-cloud-conflict-backup');
    setSyncBusy(true);
    try {
      const latest = await readCloudVault(session.user.id);
      if (!latest) throw new Error('The cloud copy could not be found. Your local copy was not changed.');
      if (latest.revision !== syncConflict.remote.revision) {
        updateCloudRevision(latest.revision);
        updateSyncConflict({ local: localCopy, remote: latest });
        setSyncStatus('The cloud copy changed again. Review the newest copy before choosing.');
        return;
      }
      const nextRevision = await updateCloudVault(session.user.id, latest.revision, localCopy);
      if (nextRevision === null) {
        const newest = await readCloudVault(session.user.id);
        if (newest) {
          updateCloudRevision(newest.revision);
          updateSyncConflict({ local: localCopy, remote: newest });
        }
        setSyncStatus('Another device changed the cloud copy. No copy was overwritten.');
        return;
      }
      updateCloudRevision(nextRevision);
      lastSyncedEnvelopeRef.current = localCopy;
      updateSyncConflict(null);
      setShowSyncConflict(false);
      setSyncStatus('This device’s encrypted vault is now synced to your account.');
      setNotice({ text: 'Cloud copy updated. An encrypted backup was downloaded.' });
    } catch (caught) {
      setSyncStatus('Could not resolve the conflict. Both vault copies remain unchanged.');
      setNotice({ text: caught instanceof Error ? caught.message : 'Could not sync this copy.', kind: 'error' });
    } finally {
      setSyncBusy(false);
    }
  };

  const useCloudCopy = async () => {
    if (!session || !syncConflict || !supabase) return;
    if (!window.confirm('My Vault will download an encrypted backup of this device’s copy, then replace it with the cloud copy. Continue?')) return;
    const localCopy = envelope ?? syncConflict.local;
    if (localCopy) downloadEnvelope(localCopy, 'my-vault-device-conflict-backup');
    setSyncBusy(true);
    try {
      const latest = await readCloudVault(session.user.id);
      if (!latest) throw new Error('The cloud copy could not be found. Your local copy was not changed.');
      if (latest.revision !== syncConflict.remote.revision) {
        updateCloudRevision(latest.revision);
        updateSyncConflict({ local: localCopy, remote: latest });
        setSyncStatus('The cloud copy changed again. Review the newest copy before choosing.');
        return;
      }
      await writeEnvelope(latest.envelope);
      setEnvelope(latest.envelope);
      setEntries([]);
      setKey(null);
      setSalt(null);
      setMasterPassword('');
      setScreen('unlock');
      updateCloudRevision(latest.revision);
      lastSyncedEnvelopeRef.current = latest.envelope;
      updateSyncConflict(null);
      setShowSyncConflict(false);
      setSyncStatus('Cloud copy loaded. Unlock it with its existing master password.');
      setNotice({ text: 'Cloud copy loaded. An encrypted backup of this device was downloaded.' });
    } catch (caught) {
      setSyncStatus('Could not load the cloud copy. Your local vault is unchanged.');
      setNotice({ text: caught instanceof Error ? caught.message : 'Could not load the cloud copy.', kind: 'error' });
    } finally {
      setSyncBusy(false);
    }
  };

  const createVault = async (event: FormEvent) => {
    event.preventDefault();
    setError('');
    if (masterPassword.length < 12) { setError('Choose a master password with at least 12 characters.'); return; }
    if (masterPassword !== confirmPassword) { setError('Those passwords do not match.'); return; }
    setBusy(true);
    try {
      const freshSalt = crypto.getRandomValues(new Uint8Array(16));
      const derived = await deriveVaultKey(masterPassword, freshSalt);
      const firstEnvelope = await sealEntriesWithKey([], derived, freshSalt);
      await writeEnvelope(firstEnvelope);
      setKey(derived);
      setSalt(envelopeSalt(firstEnvelope));
      setEnvelope(firstEnvelope);
      setEntries([]);
      setMasterPassword('');
      setConfirmPassword('');
      setScreen('vault');
      if (session) {
        const synced = await syncLocalEnvelope(session, firstEnvelope);
        if (!synced) setNotice({ text: 'Vault created and saved on this device. Cloud sync is not ready yet.', kind: 'error' });
      }
    } catch {
      setError('The encrypted vault could not be created. Check that this browser supports secure cryptography.');
    } finally { setBusy(false); }
  };

  const unlockVault = async (event: FormEvent) => {
    event.preventDefault();
    if (!envelope) return;
    setBusy(true); setError('');
    try {
      const result = await unlockEnvelope(envelope, masterPassword);
      setKey(result.key);
      setSalt(envelopeSalt(envelope));
      setEntries(result.entries);
      setMasterPassword('');
      setScreen('vault');
    } catch {
      setError('That master password did not unlock this vault. Your data has not been changed.');
    } finally { setBusy(false); }
  };

  const lockVault = () => {
    setEntries([]);
    setKey(null);
    setSalt(null);
    setMasterPassword('');
    setConfirmPassword('');
    setSearch('');
    setRevealed({});
    setEditing(null);
    setScreen('unlock');
    setError('');
  };

  const openEditor = (entry?: VaultEntry) => {
    setDraft(entry ? {
      name: entry.name, category: entry.category, username: entry.username,
      password: entry.password, website: entry.website, notes: entry.notes,
    } : blankDraft);
    setEditing(entry ?? 'new');
  };

  const saveEntry = async (event: FormEvent) => {
    event.preventDefault();
    if (!draft.name.trim() || !draft.password) return;
    const existing = editing && editing !== 'new' ? editing : undefined;
    const updatedEntry = createEntry({
      ...draft,
      name: draft.name.trim(),
      username: draft.username.trim(),
      website: draft.website.trim(),
    }, existing);
    const updated = existing
      ? entries.map((entry) => entry.id === existing.id ? updatedEntry : entry)
      : [...entries, updatedEntry];
    setBusy(true);
    try {
      const synced = await persistEntries(updated);
      setEditing(null);
      setNotice({
        text: `${existing ? 'Entry updated' : 'Entry added'}${synced === false ? ' on this device. Cloud sync is paused.' : synced ? ' and synced securely.' : ' and encrypted.'}`,
        kind: synced === false ? 'error' : 'success',
      });
    } catch { setNotice({ text: 'Could not save changes to encrypted storage.', kind: 'error' }); }
    finally { setBusy(false); }
  };

  const deleteEntry = async (entry: VaultEntry) => {
    if (!window.confirm(`Delete “${entry.name}” from your vault? This cannot be undone.`)) return;
    try {
      const synced = await persistEntries(entries.filter((item) => item.id !== entry.id));
      setNotice({
        text: `${entry.name} deleted${synced === false ? ' on this device. Cloud sync is paused.' : synced ? ' and synced securely.' : '.'}`,
        kind: synced === false ? 'error' : 'success',
      });
    } catch { setNotice({ text: 'Could not delete this entry.', kind: 'error' }); }
  };

  const copyValue = async (value: string, label: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setNotice({ text: `${label} copied to clipboard.` });
    } catch { setNotice({ text: 'Clipboard access is unavailable in this browser.', kind: 'error' }); }
  };

  const exportBackup = () => {
    if (!envelope) return;
    downloadEnvelope(envelope, 'my-vault-backup');
    setNotice({ text: 'Encrypted backup downloaded. Keep it somewhere safe.' });
  };

  const importBackup = async (file?: File) => {
    if (!file) return;
    try {
      const data: unknown = JSON.parse(await file.text());
      if (!isEnvelope(data)) throw new Error('Choose a valid My Vault encrypted backup file.');
      if (!window.confirm('Replace this browser’s vault with the selected encrypted backup?')) return;
      await writeEnvelope(data);
      lockVault();
      setEnvelope(data);
      if (session) {
        const reconciled = await reconcileAccount(session, data);
        setEnvelope(reconciled ?? data);
      }
      setNotice({ text: 'Encrypted backup imported. Unlock it with its original master password.' });
    } catch (caught) {
      setNotice({ text: caught instanceof Error ? caught.message : 'That backup file could not be read.', kind: 'error' });
    } finally {
      if (importRef.current) importRef.current.value = '';
    }
  };

  const installApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    await installPrompt.userChoice;
    setInstallPrompt(null);
  };
  const toggleTheme = () => setTheme((current) => current === 'dark' ? 'light' : 'dark');
  const retryLocalStorage = async () => {
    setError('');
    setScreen('loading');
    try {
      let saved = await readEnvelope();
      if (session && cloudSyncConfigured) saved = await reconcileAccount(session, saved);
      setEnvelope(saved);
      setScreen(saved ? 'unlock' : 'create');
    } catch {
      setError('Local encrypted storage still cannot be opened. Your existing data was not changed.');
      setScreen('storage-error');
    }
  };

  const accountDialogOverlay = accountDialogOpen ? <AccountDialog
    email={session?.user.email ?? null}
    mode={accountMode}
    setMode={(mode) => { setAccountMode(mode); setAccountError(''); setAccountMessage(''); }}
    busy={accountBusy}
    error={accountError}
    message={accountMessage}
    cloudConfigured={cloudSyncConfigured}
    syncStatus={syncStatus}
    onSubmit={submitAccountForm}
    onSignOut={() => { void signOutAccount(); }}
    onClose={() => setAccountDialogOpen(false)}
  /> : null;

  const conflictDialogOverlay = showSyncConflict && syncConflict ? <SyncConflictDialog
    localAvailable={Boolean(syncConflict.local)}
    cloudUpdatedAt={syncConflict.remote.updatedAt}
    busy={syncBusy}
    onKeepLocal={() => { void keepLocalCopy(); }}
    onUseCloud={() => { void useCloudCopy(); }}
    onClose={() => setShowSyncConflict(false)}
  /> : null;

  if (screen === 'loading') return <main className="screen-center" aria-live="polite"><section className="auth-card"><Brand/><p className="auth-copy">Opening your private space…</p></section></main>;

  if (screen === 'storage-error') return <main className="screen-center" aria-live="polite"><section className="auth-card">
    <Brand/><h1>Local vault storage is unavailable</h1><p className="auth-copy">{error}</p>
    <button className="button button-outline" data-testid="button-retry-storage" onClick={() => { void retryLocalStorage(); }}>Try again</button>
  </section></main>;

  if (screen === 'create' || screen === 'unlock') {
    const creating = screen === 'create';
    return <>
      <LockScreen
      creating={creating}
      theme={theme}
      onToggleTheme={toggleTheme}
      masterPassword={masterPassword}
      setMasterPassword={setMasterPassword}
      confirmPassword={confirmPassword}
      setConfirmPassword={setConfirmPassword}
      showMaster={showMaster}
      setShowMaster={setShowMaster}
      busy={busy}
      error={error}
      accountEmail={session?.user.email ?? null}
      cloudConfigured={cloudSyncConfigured}
      syncStatus={syncStatus}
      hasSyncConflict={Boolean(syncConflict)}
      onAccountOpen={openAccountDialog}
      onResolveConflict={() => setShowSyncConflict(true)}
      onSubmit={(event) => { void (creating ? createVault(event) : unlockVault(event)); }}
      />
      {accountDialogOverlay}
      {conflictDialogOverlay}
    </>;
  }

  return <main className="app-shell">
    <header className="topbar">
      <Brand />
      <div className="top-actions">
        <button className="button button-outline" data-testid="button-open-account" onClick={openAccountDialog}>
          <Cloud size={15}/>{session?.user.email ? 'Account' : 'Sign in'}
        </button>
        <ThemeToggle theme={theme} onToggle={toggleTheme} />
        {installPrompt && <button className="button button-outline" data-testid="button-install-app" onClick={installApp}><ArrowDownToLine size={15}/> Install</button>}
        <button className="button button-outline" data-testid="button-export-backup" onClick={exportBackup}><ArrowDownToLine size={15}/> Backup</button>
        <button className="button button-icon" data-testid="button-lock-vault" onClick={lockVault} aria-label="Lock vault" title="Lock vault"><LogOut size={17}/></button>
      </div>
    </header>
    <section className="hero">
      <div>
        <div className="eyebrow">Your private account keeper</div>
        <h1>Everything, in its place.</h1>
        <p>A little order for all the accounts that make up your online life.</p>
      </div>
      <div className="safe-note"><ShieldCheck size={17}/><span>Encrypted on this device</span></div>
    </section>
    <section className={`sync-banner${syncConflict ? ' sync-banner--conflict' : ''}`} data-testid="status-cloud-sync">
      <Cloud size={17}/>
      <div className="sync-banner__copy">
        <strong>{session?.user.email ?? 'Cloud sync'}</strong>
        <span>{syncStatus}</span>
      </div>
      {syncConflict && <button className="button button-outline" type="button" data-testid="button-resolve-sync" onClick={() => setShowSyncConflict(true)}>Resolve copies</button>}
    </section>
    <div className="toolbar">
      <div className="search-wrap">
        <Search size={17} aria-hidden="true"/>
        <input className="search-input" type="search" aria-label="Search vault entries" data-testid="input-search-vault" placeholder="Find an account…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      <div className="filters" role="group" aria-label="Filter by category">
        {(['All', 'Game', 'Social', 'Other'] as const).map((item) => <button key={item} data-testid={`filter-${item.toLowerCase()}`} className={`filter-button ${filter === item ? 'active' : ''}`} aria-pressed={filter === item} onClick={() => setFilter(item)}>{item}</button>)}
      </div>
      <button className="button button-primary" data-testid="button-add-entry" onClick={() => openEditor()}><Plus size={17}/> Add account</button>
    </div>
    {sortedEntries.length > 0 ? <section className="vault-grid" aria-label="Vault entries" data-testid="list-vault-entries">
      {sortedEntries.map((entry, index) => <article className="entry-card" key={entry.id} data-testid={`card-entry-${entry.id}`} style={{ animationDelay: `${Math.min(index, 8) * 35}ms` }}>
        <div className="entry-head">
          <div className="entry-ident">
            <div className="entry-monogram" aria-hidden="true">{entry.name.trim().slice(0, 1).toLocaleUpperCase()}</div>
            <div style={{minWidth:0}}>
              <div className="entry-title" data-testid={`text-entry-name-${entry.id}`}>{entry.name}</div>
              <div className="entry-category">{entry.category}</div>
            </div>
          </div>
          <div className="entry-tools">
            <button className="button-icon" data-testid={`button-edit-${entry.id}`} aria-label={`Edit ${entry.name}`} title="Edit" onClick={() => openEditor(entry)}><Pencil size={15}/></button>
            <button className="button-icon" data-testid={`button-delete-${entry.id}`} aria-label={`Delete ${entry.name}`} title="Delete" onClick={() => void deleteEntry(entry)}><Trash2 size={15}/></button>
          </div>
        </div>
        <div className="entry-detail">
          <span className="entry-user" title={entry.username || 'No username saved'}>{entry.username || 'No username saved'}</span>
          <div className="credential-tools">
            <button className="button-icon" data-testid={`button-copy-username-${entry.id}`} aria-label={`Copy username for ${entry.name}`} title="Copy username" onClick={() => void copyValue(entry.username, 'Username')}><Copy size={14}/></button>
          </div>
        </div>
        <div className="entry-detail" style={{marginTop:-6}}>
          <span className="entry-user" data-testid={`text-password-${entry.id}`}>{revealed[entry.id] ? entry.password : '••••••••••••'}</span>
          <div className="credential-tools">
            <button className="button-icon" data-testid={`button-reveal-${entry.id}`} aria-label={`${revealed[entry.id] ? 'Hide' : 'Reveal'} password for ${entry.name}`} title={revealed[entry.id] ? 'Hide password' : 'Reveal password'} onClick={() => setRevealed((current) => ({...current, [entry.id]: !current[entry.id]}))}>{revealed[entry.id] ? <EyeOff size={14}/> : <Eye size={14}/>}</button>
            <button className="button-icon" data-testid={`button-copy-password-${entry.id}`} aria-label={`Copy password for ${entry.name}`} title="Copy password" onClick={() => void copyValue(entry.password, 'Password')}><Copy size={14}/></button>
          </div>
        </div>
        {entry.notes && <p title={entry.notes} style={{margin:'0 1px 13px',color:'#819084',fontSize:11,lineHeight:1.5,overflow:'hidden',display:'-webkit-box',WebkitLineClamp:2,WebkitBoxOrient:'vertical'}}>{entry.notes}</p>}
        <div className="entry-meta">
          <span className="entry-site">{entry.website ? <><Globe2 size={12} style={{verticalAlign:'-2px',marginRight:5}}/>{entry.website}</> : 'No website'}</span>
          <span>Updated {new Date(entry.updatedAt).toLocaleDateString(undefined, {month:'short',day:'numeric',year:'numeric'})}</span>
        </div>
      </article>)}
    </section> : <section className="empty-state" data-testid="status-empty-vault">
      <div className="empty-icon">{search || filter !== 'All' ? <Search size={23}/> : <KeyRound size={23}/>}</div>
      <h2>{entries.length === 0 ? 'A fresh start.' : 'Nothing found here.'}</h2>
      <p>{entries.length === 0 ? 'Add your first account. It will be encrypted before it is saved to this device.' : 'Try another name or switch the category filter.'}</p>
      {entries.length === 0 ? <button className="button button-primary" data-testid="button-empty-add-entry" onClick={() => openEditor()}><Plus size={16}/> Add your first account</button> : <button className="button button-outline" onClick={() => {setSearch('');setFilter('All');}}>Clear filters</button>}
    </section>}
    <footer className="security-footer">
      <span><LockKeyhole size={14}/> Encrypted on this device; cloud status shown above</span>
      <span><button className="button button-danger" data-testid="button-import-backup" style={{minHeight:30,padding:'0 7px',fontSize:11}} onClick={() => importRef.current?.click()}><ArrowUpFromLine size={14}/> Import backup</button> · {session ? 'Account sync enabled' : 'Sign in to sync'}</span>
      <input ref={importRef} className="hidden-input" type="file" accept="application/json,.json" data-testid="input-import-backup" onChange={(event) => void importBackup(event.target.files?.[0])}/>
    </footer>
    {editing && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => {if (event.target === event.currentTarget) setEditing(null);}}>
      <section className="modal" role="dialog" aria-modal="true" aria-labelledby="entry-modal-title">
        <div className="modal-head"><div><h2 id="entry-modal-title">{editing === 'new' ? 'Add an account' : 'Edit account'}</h2><p>Only the encrypted version is saved.</p></div><button className="button-icon" data-testid="button-close-entry-modal" aria-label="Close" onClick={() => setEditing(null)}><X size={17}/></button></div>
        <form onSubmit={(event) => void saveEntry(event)}>
          <div className="form-grid">
            <div className="field-block full-span"><label className="form-label" htmlFor="entry-name">Account name *</label><input autoFocus id="entry-name" className="form-field" data-testid="input-entry-name" value={draft.name} onChange={(e) => setDraft({...draft,name:e.target.value})} placeholder="e.g. Steam" required maxLength={100}/></div>
            <div className="field-block"><label className="form-label" htmlFor="entry-category">Category</label><select id="entry-category" className="form-field" data-testid="select-entry-category" value={draft.category} onChange={(e) => setDraft({...draft,category:e.target.value as Category})}><option>Game</option><option>Social</option><option>Other</option></select></div>
            <div className="field-block"><label className="form-label" htmlFor="entry-website">Website</label><input id="entry-website" className="form-field" data-testid="input-entry-website" value={draft.website} onChange={(e) => setDraft({...draft,website:e.target.value})} placeholder="https://…" maxLength={300}/></div>
            <div className="field-block"><label className="form-label" htmlFor="entry-username">Username or email</label><input id="entry-username" className="form-field" data-testid="input-entry-username" autoComplete="off" value={draft.username} onChange={(e) => setDraft({...draft,username:e.target.value})} maxLength={300}/></div>
            <div className="field-block"><label className="form-label" htmlFor="entry-password">Password *</label><div className="password-field-wrap"><input id="entry-password" className="form-field" data-testid="input-entry-password" autoComplete="new-password" type={revealed.form ? 'text' : 'password'} value={draft.password} onChange={(e) => setDraft({...draft,password:e.target.value})} required maxLength={1000}/><button type="button" aria-label={revealed.form ? 'Hide password' : 'Show password'} onClick={() => setRevealed({...revealed,form:!revealed.form})}>{revealed.form ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div></div>
            <div className="field-block full-span"><label className="form-label" htmlFor="entry-notes">Notes</label><textarea id="entry-notes" className="form-field" data-testid="input-entry-notes" value={draft.notes} onChange={(e) => setDraft({...draft,notes:e.target.value})} placeholder="Recovery details or anything worth remembering…" maxLength={2000}/></div>
          </div>
          <div className="modal-actions"><button type="button" className="button button-outline" onClick={() => setEditing(null)}>Cancel</button><button type="submit" className="button button-primary" data-testid="button-save-entry" disabled={busy}>{busy ? 'Encrypting…' : <><Check size={16}/> Save account</>}</button></div>
        </form>
      </section>
    </div>}
    {notice && <div className="notice" role={notice.kind === 'error' ? 'alert' : 'status'} data-testid="status-notice">{notice.kind === 'error' ? <X size={16}/> : <Check size={16}/>} {notice.text}</div>}
    {accountDialogOverlay}
    {conflictDialogOverlay}
  </main>;
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export default App;
