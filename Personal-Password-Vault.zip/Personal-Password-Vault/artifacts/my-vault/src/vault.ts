export type Category = 'Game' | 'Social' | 'Other';
export type VaultEntry = {
  id: string;
  name: string;
  category: Category;
  username: string;
  password: string;
  website: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
};

export type VaultEnvelope = {
  format: 'my-vault-encrypted';
  version: 1;
  kdf: 'PBKDF2-HMAC-SHA-256';
  iterations: 600000;
  cipher: 'AES-GCM-256';
  salt: string;
  iv: string;
  ciphertext: string;
};

const DB_NAME = 'my-vault-local';
const STORE_NAME = 'vault';
const RECORD_KEY = 'primary';
const ITERATIONS = 600000;
const encoder = new TextEncoder();
const decoder = new TextDecoder();

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE_NAME);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Could not open local vault storage.'));
  });
}

export async function readEnvelope(): Promise<VaultEnvelope | null> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const request = tx.objectStore(STORE_NAME).get(RECORD_KEY);
    request.onsuccess = () => { resolve(request.result ?? null); db.close(); };
    request.onerror = () => { reject(request.error); db.close(); };
  });
}

export async function writeEnvelope(envelope: VaultEnvelope): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(envelope, RECORD_KEY);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error ?? new Error('Could not save encrypted vault.')); };
    tx.onabort = () => { db.close(); reject(tx.error ?? new Error('Saving the vault was interrupted.')); };
  });
}

export async function clearEnvelope(): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).delete(RECORD_KEY);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error); };
  });
}

function toBase64(bytes: Uint8Array): string {
  let binary = '';
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary);
}

function fromBase64(value: string): Uint8Array {
  const binary = atob(value);
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function asArrayBuffer(bytes: Uint8Array): ArrayBuffer {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return copy.buffer;
}

export async function deriveVaultKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const material = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: asArrayBuffer(salt), iterations: ITERATIONS, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );
}

export async function sealEntries(entries: VaultEntry[], password: string, prior?: VaultEnvelope): Promise<VaultEnvelope> {
  const salt = prior ? fromBase64(prior.salt) : crypto.getRandomValues(new Uint8Array(16));
  const key = await deriveVaultKey(password, salt);
  return sealEntriesWithKey(entries, key, salt);
}

export async function sealEntriesWithKey(entries: VaultEntry[], key: CryptoKey, salt: Uint8Array): Promise<VaultEnvelope> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoder.encode(JSON.stringify(entries)));
  return {
    format: 'my-vault-encrypted',
    version: 1,
    kdf: 'PBKDF2-HMAC-SHA-256',
    iterations: ITERATIONS,
    cipher: 'AES-GCM-256',
    salt: toBase64(salt),
    iv: toBase64(iv),
    ciphertext: toBase64(new Uint8Array(ciphertext)),
  };
}

export async function openEntries(envelope: VaultEnvelope, password: string): Promise<VaultEntry[]> {
  return (await unlockEnvelope(envelope, password)).entries;
}

export async function unlockEnvelope(envelope: VaultEnvelope, password: string): Promise<{ entries: VaultEntry[]; key: CryptoKey }> {
  if (!isEnvelope(envelope)) throw new Error('This backup is not a supported My Vault encrypted backup.');
  const key = await deriveVaultKey(password, fromBase64(envelope.salt));
  return { entries: await openEntriesWithKey(envelope, key), key };
}

export async function openEntriesWithKey(envelope: VaultEnvelope, key: CryptoKey): Promise<VaultEntry[]> {
  if (!isEnvelope(envelope)) throw new Error('This backup is not a supported My Vault encrypted backup.');
  const clear = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: asArrayBuffer(fromBase64(envelope.iv)) },
    key,
    asArrayBuffer(fromBase64(envelope.ciphertext)),
  );
  const parsed: unknown = JSON.parse(decoder.decode(clear));
  if (!Array.isArray(parsed) || !parsed.every(isEntry)) throw new Error('The decrypted vault contents are invalid.');
  return parsed;
}

export function envelopeSalt(envelope: VaultEnvelope): Uint8Array { return fromBase64(envelope.salt); }

export function isEnvelope(value: unknown): value is VaultEnvelope {
  if (!value || typeof value !== 'object') return false;
  const envelope = value as Partial<VaultEnvelope>;
  return envelope.format === 'my-vault-encrypted' && envelope.version === 1
    && envelope.kdf === 'PBKDF2-HMAC-SHA-256' && envelope.iterations === ITERATIONS
    && envelope.cipher === 'AES-GCM-256' && typeof envelope.salt === 'string'
    && typeof envelope.iv === 'string' && typeof envelope.ciphertext === 'string';
}

function isEntry(value: unknown): value is VaultEntry {
  if (!value || typeof value !== 'object') return false;
  const item = value as Partial<VaultEntry>;
  return typeof item.id === 'string' && typeof item.name === 'string'
    && (item.category === 'Game' || item.category === 'Social' || item.category === 'Other')
    && typeof item.username === 'string' && typeof item.password === 'string'
    && typeof item.website === 'string' && typeof item.notes === 'string'
    && typeof item.createdAt === 'string' && typeof item.updatedAt === 'string';
}

export function createEntry(values: Omit<VaultEntry, 'id' | 'createdAt' | 'updatedAt'>, existing?: VaultEntry): VaultEntry {
  const now = new Date().toISOString();
  return { ...values, id: existing?.id ?? crypto.randomUUID(), createdAt: existing?.createdAt ?? now, updatedAt: now };
}
