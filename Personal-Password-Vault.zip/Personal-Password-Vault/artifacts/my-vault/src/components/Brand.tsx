import { Fingerprint } from 'lucide-react';

export function Brand() {
  return (
    <div className="brand" aria-label="My Vault">
      <span className="brand-mark"><Fingerprint size={22} strokeWidth={1.8} /></span>
      <span className="brand-copy">
        <span className="brand-title">my vault</span>
        <span className="brand-caption">just for you</span>
      </span>
    </div>
  );
}
