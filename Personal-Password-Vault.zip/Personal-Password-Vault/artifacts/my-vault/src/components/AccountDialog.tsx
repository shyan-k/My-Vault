import { zodResolver } from '@hookform/resolvers/zod';
import { Cloud, ShieldCheck, X } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';

export type AccountMode = 'sign-in' | 'sign-up';
const accountSchema = z.object({
  email: z.string().email('Enter a valid email address.').max(320),
  password: z.string().min(8, 'Use at least 8 characters.'),
});
export type AccountCredentials = z.infer<typeof accountSchema>;

type AccountDialogProps = {
  email: string | null;
  mode: AccountMode;
  setMode: (mode: AccountMode) => void;
  busy: boolean;
  error: string;
  message: string;
  cloudConfigured: boolean;
  syncStatus: string;
  onSubmit: (credentials: AccountCredentials) => Promise<void>;
  onSignOut: () => void;
  onClose: () => void;
};

export function AccountDialog({
  email,
  mode,
  setMode,
  busy,
  error,
  message,
  cloudConfigured,
  syncStatus,
  onSubmit,
  onSignOut,
  onClose,
}: AccountDialogProps) {
  const form = useForm<AccountCredentials>({
    resolver: zodResolver(accountSchema),
    defaultValues: { email: '', password: '' },
  });

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => {
      if (event.target === event.currentTarget && !busy) onClose();
    }}>
      <section className="modal account-dialog" role="dialog" aria-modal="true" aria-labelledby="account-dialog-title">
        <div className="modal-head">
          <div>
            <h2 id="account-dialog-title">{email ? 'Cloud account' : mode === 'sign-up' ? 'Create your sync account' : 'Sign in to sync'}</h2>
            <p>{email ? 'Your encrypted vault is linked to this account.' : 'Use a separate account to sync your encrypted vault across devices.'}</p>
          </div>
          <button className="button-icon" type="button" data-testid="button-close-account-dialog" aria-label="Close account dialog" onClick={onClose}>
            <X size={17} />
          </button>
        </div>

        {!cloudConfigured ? (
          <div className="security-callout" role="status" data-testid="status-cloud-unconfigured">
            <Cloud size={17} />
            Cloud sync needs Supabase project settings before it can be used.
          </div>
        ) : email ? (
          <>
            <div className="account-summary">
              <span className="account-summary__icon"><ShieldCheck size={18} /></span>
              <div>
                <strong data-testid="text-account-email">{email}</strong>
                <p data-testid="status-account-sync">{syncStatus}</p>
              </div>
            </div>
            <p className="dialog-copy">Signing out leaves the encrypted vault saved on this device. It does not delete your cloud copy.</p>
            <div className="modal-actions">
              <button className="button button-outline" type="button" onClick={onClose}>Close</button>
              <button className="button button-danger" type="button" data-testid="button-sign-out" onClick={onSignOut} disabled={busy}>Sign out</button>
            </div>
          </>
        ) : (
          <Form {...form}>
          <form onSubmit={form.handleSubmit(async (credentials) => {
            await onSubmit(credentials);
            form.resetField('password');
          })}>
            <div className="account-mode-switch" role="group" aria-label="Account action">
              <button type="button" data-testid="button-switch-sign-in" className={mode === 'sign-in' ? 'active' : ''} aria-pressed={mode === 'sign-in'} onClick={() => setMode('sign-in')}>Sign in</button>
              <button type="button" data-testid="button-switch-sign-up" className={mode === 'sign-up' ? 'active' : ''} aria-pressed={mode === 'sign-up'} onClick={() => setMode('sign-up')}>Create account</button>
            </div>
            <FormField control={form.control} name="email" render={({ field }) => (
              <FormItem className="field-block">
                <FormLabel className="form-label">Email</FormLabel>
                <FormControl><Input className="form-field" data-testid="input-account-email" type="email" autoComplete="email" maxLength={320} {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="password" render={({ field }) => (
              <FormItem className="field-block">
                <FormLabel className="form-label">Account password</FormLabel>
                <FormControl><Input className="form-field" data-testid="input-account-password" type="password" autoComplete={mode === 'sign-up' ? 'new-password' : 'current-password'} {...field} /></FormControl>
                <FormDescription className="account-field-hint">This is separate from your vault master password.</FormDescription>
                <FormMessage />
              </FormItem>
            )} />
            {error && <p className="inline-error" role="alert" data-testid="status-account-error">{error}</p>}
            {message && <p className="account-message" role="status" data-testid="status-account-message">{message}</p>}
            <div className="security-callout">
              <ShieldCheck size={17} />
              Only encrypted vault data is stored in the cloud. Your master password is never sent.
            </div>
            <button className="button button-primary account-submit" type="submit" data-testid="button-submit-account" disabled={busy}>
              {busy ? 'Connecting…' : mode === 'sign-up' ? 'Create account' : 'Sign in'}
            </button>
          </form>
          </Form>
        )}
      </section>
    </div>
  );
}
