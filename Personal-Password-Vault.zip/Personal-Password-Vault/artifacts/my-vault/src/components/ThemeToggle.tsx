import { Moon, Sun } from 'lucide-react';

export type ThemeMode = 'dark' | 'light';

export function ThemeToggle({ theme, onToggle }: { theme: ThemeMode; onToggle: () => void }) {
  const isDark = theme === 'dark';
  return (
    <button
      className="button button-icon theme-toggle"
      type="button"
      data-testid="button-toggle-theme"
      aria-label={`Switch to ${isDark ? 'light' : 'dark'} theme`}
      aria-pressed={isDark}
      title={`Switch to ${isDark ? 'light' : 'dark'} theme`}
      onClick={onToggle}
    >
      {isDark ? <Sun size={17} aria-hidden="true" /> : <Moon size={17} aria-hidden="true" />}
      <span className="sr-only">{isDark ? 'Dark theme enabled' : 'Light theme enabled'}</span>
    </button>
  );
}
