import { Cloud, HardDrive, ShieldAlert, X } from 'lucide-react';

type SyncConflictDialogProps = {
  localAvailable: boolean;
  cloudUpdatedAt: string;
  busy: boolean;
  onKeepLocal: () => void;
  onUseCloud: () => void;
  onClose: () => void;
};

export function SyncConflictDialog({
  localAvailable,
  cloudUpdatedAt,
  busy,
  onKeepLocal,
  onUseCloud,
  onClose,
}: SyncConflictDialogProps) {
  const formattedCloudDate = cloudUpdatedAt && !Number.isNaN(Date.parse(cloudUpdatedAt))
    ? new Date(cloudUpdatedAt).toLocaleString()
    : 'date unavailable';

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => {
      if (event.target === event.currentTarget && !busy) onClose();
    }}>
      <section className="modal sync-conflict-dialog" role="dialog" aria-modal="true" aria-labelledby="sync-conflict-title">
        <div className="modal-head">
          <div>
            <h2 id="sync-conflict-title">Two vault copies found</h2>
            <p>Neither copy has been replaced.</p>
          </div>
          <button className="button-icon" type="button" data-testid="button-close-sync-conflict" aria-label="Close sync conflict" onClick={onClose} disabled={busy}>
            <X size={17} />
          </button>
        </div>
        <div className="security-callout warning-callout">
          <ShieldAlert size={17} />
          Choose which encrypted copy to use. Before replacing either copy, My Vault downloads an encrypted backup of it to this device.
        </div>
        <div className="conflict-copies">
          {localAvailable && <div className="conflict-copy">
            <HardDrive size={17} />
            <div><strong>This device</strong><span>The existing local vault</span></div>
          </div>}
          <div className="conflict-copy">
            <Cloud size={17} />
            <div><strong>Cloud copy</strong><span>Last updated {formattedCloudDate}</span></div>
          </div>
        </div>
        <div className="conflict-actions">
          {localAvailable && <button className="button button-outline" type="button" data-testid="button-keep-local-vault" onClick={onKeepLocal} disabled={busy}>
            {busy ? 'Saving safely…' : 'Keep this device’s copy'}
          </button>}
          <button className="button button-primary" type="button" data-testid="button-use-cloud-vault" onClick={onUseCloud} disabled={busy}>
            {busy ? 'Saving safely…' : 'Use cloud copy here'}
          </button>
        </div>
        <p className="dialog-copy">Your vault master password is required to unlock whichever copy you choose. The account password cannot unlock vault entries.</p>
      </section>
    </div>
  );
}
