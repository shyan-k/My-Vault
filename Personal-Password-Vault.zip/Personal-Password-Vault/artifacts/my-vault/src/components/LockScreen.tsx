import { useState, type FormEvent } from 'react';
import { Eye, EyeOff, KeyRound, LockKeyhole, ShieldAlert } from 'lucide-react';
import { Brand } from './Brand';
import { ThemeToggle, type ThemeMode } from './ThemeToggle';
import './lock-screen.css';

type LockScreenProps = {
  creating: boolean;
  theme: ThemeMode;
  onToggleTheme: () => void;
  masterPassword: string;
  setMasterPassword: (value: string) => void;
  confirmPassword: string;
  setConfirmPassword: (value: string) => void;
  showMaster: boolean;
  setShowMaster: (show: boolean) => void;
  busy: boolean;
  error: string;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  accountEmail: string | null;
  cloudConfigured: boolean;
  syncStatus: string;
  hasSyncConflict: boolean;
  onAccountOpen: () => void;
  onResolveConflict: () => void;
};

export function LockScreen({
  creating,
  theme,
  onToggleTheme,
  masterPassword,
  setMasterPassword,
  confirmPassword,
  setConfirmPassword,
  showMaster,
  setShowMaster,
  busy,
  error,
  onSubmit,
  accountEmail,
  cloudConfigured,
  syncStatus,
  hasSyncConflict,
  onAccountOpen,
  onResolveConflict,
}: LockScreenProps) {
  const [isAwake, setIsAwake] = useState(false);
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    setIsAwake(true);
    onSubmit(event);
  };

  return (
    <main className={`lock-screen${theme === 'light' ? ' lock-screen--light' : ''}`}>
      <div className="lock-screen__grain" aria-hidden="true" />
      <div className="lock-screen__ambient lock-screen__ambient--one" aria-hidden="true" />
      <div className="lock-screen__ambient lock-screen__ambient--two" aria-hidden="true" />

      <header className="lock-screen__topbar">
        <Brand />
        <ThemeToggle theme={theme} onToggle={onToggleTheme} />
      </header>

      <section className="lock-screen__layout" aria-labelledby="lock-screen-title">
        <aside className="lock-screen__sanctuary" aria-label="Vault security">
          <div className={`lock-screen__seal${isAwake ? ' lock-screen__seal--awake' : ''}`} aria-hidden="true">
            <span className="lock-screen__seal-orbit lock-screen__seal-orbit--outer" />
            <span className="lock-screen__seal-orbit lock-screen__seal-orbit--middle" />
            <span className="lock-screen__seal-orbit lock-screen__seal-orbit--inner" />
            <span className="lock-screen__seal-core"><LockKeyhole size={28} strokeWidth={1.45} /></span>
            <span className="lock-screen__seal-spark lock-screen__seal-spark--a" />
            <span className="lock-screen__seal-spark lock-screen__seal-spark--b" />
          </div>
          <div className="lock-screen__sanctuary-copy">
            <span className="lock-screen__overline"><span /> Private by design</span>
            <p>Your keys stay<br />close to home.</p>
            <span className="lock-screen__device-note">Encrypted on this device</span>
          </div>
          <div className="lock-screen__side-rule" aria-hidden="true" />
        </aside>

        <div className="lock-screen__form-panel">
          <div className="lock-screen__eyebrow">
            <span className="lock-screen__status-dot" />
            {creating ? 'A private place for your logins' : 'Your vault is locked'}
          </div>
          <h1 id="lock-screen-title">{creating ? 'Start with a master key.' : 'Welcome back.'}</h1>
          <p className="lock-screen__intro">
            {creating
              ? 'One strong password protects everything you keep here. Your vault stays encrypted on this device.'
              : 'Enter your master password to decrypt your vault on this device.'}
          </p>

          <form onSubmit={handleSubmit}>
            <div className="lock-screen__field-block">
              <label className="lock-screen__label" htmlFor="master-password">
                {creating ? 'Create master password' : 'Master password'}
              </label>
              <div className="lock-screen__field-frame">
                <input
                  id="master-password"
                  data-testid="input-master-password"
                  className="lock-screen__input"
                  type={showMaster ? 'text' : 'password'}
                  value={masterPassword}
                  onChange={(event) => setMasterPassword(event.target.value)}
                  autoComplete={creating ? 'new-password' : 'current-password'}
                  required
                  autoFocus
                  aria-describedby="master-password-hint"
                />
                <button
                  className="lock-screen__reveal"
                  aria-label={showMaster ? 'Hide master password' : 'Show master password'}
                  title={showMaster ? 'Hide master password' : 'Show master password'}
                  type="button"
                  onClick={() => setShowMaster(!showMaster)}
                >
                  {showMaster ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
              <span className="lock-screen__field-hint" id="master-password-hint">
                {creating ? 'Choose a long, unique passphrase you can remember.' : 'Only used here, on this device.'}
              </span>
            </div>

            {creating && (
              <div className="lock-screen__field-block">
                <label className="lock-screen__label" htmlFor="confirm-password">Confirm master password</label>
                <input
                  id="confirm-password"
                  data-testid="input-confirm-password"
                  className="lock-screen__input"
                  type={showMaster ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(event) => setConfirmPassword(event.target.value)}
                  autoComplete="new-password"
                  required
                />
              </div>
            )}

            <button
              className="lock-screen__unlock"
              data-testid={creating ? 'button-create-vault' : 'button-unlock-vault'}
              type="submit"
              disabled={busy}
            >
              {busy
                ? 'Working securely…'
                : creating
                  ? <><KeyRound size={16} strokeWidth={1.8} /><span>Create my vault</span></>
                  : <><LockKeyhole size={16} strokeWidth={1.8} /><span>Unlock vault</span></>}
            </button>
            {error && <p className="lock-screen__error" role="alert" data-testid="status-auth-error">{error}</p>}
          </form>

          <div className="lock-screen__warning" role="note">
            <span className="lock-screen__warning-icon"><ShieldAlert size={17} strokeWidth={1.8} /></span>
            <p><strong>No recovery option.</strong> Your master password is never stored. If you forget it, this vault cannot be recovered.</p>
          </div>

          <div className="lock-screen__cloud" data-testid="status-lock-screen-cloud">
            <div>
              <strong>{accountEmail || 'Sync across devices'}</strong>
              <span>{syncStatus}</span>
            </div>
            <div className="lock-screen__cloud-actions">
              {hasSyncConflict && <button type="button" data-testid="button-resolve-lock-screen-sync" onClick={onResolveConflict}>Resolve copies</button>}
              <button type="button" data-testid="button-open-account" onClick={onAccountOpen} disabled={!cloudConfigured}>
                {accountEmail ? 'Account' : 'Sign in'}
              </button>
            </div>
          </div>
        </div>
      </section>

      <footer className="lock-screen__footer">
        <span className="lock-screen__footer-line" />
        <span>LOCAL FIRST <i aria-hidden="true">·</i> PRIVATE ALWAYS</span>
        <span className="lock-screen__footer-line" />
      </footer>
    </main>
  );
}
