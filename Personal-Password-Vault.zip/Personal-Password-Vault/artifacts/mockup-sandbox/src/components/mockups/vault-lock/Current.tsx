import { useState } from 'react';
import { Eye, EyeOff, Fingerprint, LockKeyhole, ShieldCheck } from 'lucide-react';
import './_group.css';

function Brand() {
  return (
    <div className="brand" aria-label="My Vault">
      <span className="brand-mark"><Fingerprint size={22} strokeWidth={1.8} /></span>
      <span>
        <span className="brand-title">my vault</span>
        <span className="brand-caption">just for you</span>
      </span>
    </div>
  );
}

export function Current() {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <main className="lock-demo screen-center">
      <section className="auth-card" aria-labelledby="auth-title">
        <Brand />
        <div className="lock-screen-mark"><LockKeyhole size={28} strokeWidth={1.7} /></div>
        <div className="eyebrow">Your vault is locked</div>
        <h1 id="auth-title">Welcome back.</h1>
        <p className="auth-copy">Enter your master password to decrypt your vault on this device.</p>
        <form onSubmit={(event) => event.preventDefault()}>
          <div className="field-block">
            <label className="form-label" htmlFor="master-password">Master password</label>
            <div className="password-field-wrap">
              <input
                id="master-password"
                className="form-field"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                autoFocus
                required
              />
              <button
                aria-label={showPassword ? 'Hide master password' : 'Show master password'}
                type="button"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>
          </div>
          <button className="button button-primary" type="submit">
            <LockKeyhole size={16} /> Unlock vault
          </button>
        </form>
        <div className="security-callout warning-callout">
          <ShieldCheck size={17} aria-hidden="true" />
          <span><strong>No recovery option.</strong> Your master password is never stored. If you forget it, this vault cannot be recovered.</span>
        </div>
      </section>
    </main>
  );
}
