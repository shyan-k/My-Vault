import { useState, type FormEvent } from 'react';
import {
  Eye,
  EyeOff,
  Fingerprint,
  LockKeyhole,
  Moon,
  ShieldAlert,
  Sun,
} from 'lucide-react';
import './AnimatedLock.css';

export function AnimatedLock() {
  const [showPassword, setShowPassword] = useState(false);
  const [isLight, setIsLight] = useState(false);
  const [previewMessage, setPreviewMessage] = useState('');

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPreviewMessage('Preview only — no vault data was accessed.');
  }

  return (
    <main className={`animated-lock${isLight ? ' animated-lock--light' : ''}`}>
      <div className="animated-lock__grain" aria-hidden="true" />
      <div className="animated-lock__ambient animated-lock__ambient--one" aria-hidden="true" />
      <div className="animated-lock__ambient animated-lock__ambient--two" aria-hidden="true" />

      <header className="animated-lock__topbar">
        <div className="animated-lock__brand" aria-label="My Vault, just for you">
          <span className="animated-lock__brand-mark"><Fingerprint size={21} strokeWidth={1.65} /></span>
          <span className="animated-lock__brand-copy">
            <span className="animated-lock__brand-name">my vault</span>
            <span className="animated-lock__brand-caption">just for you</span>
          </span>
        </div>
        <button
          className="animated-lock__theme"
          type="button"
          onClick={() => setIsLight((current) => !current)}
          aria-label={`Switch to ${isLight ? 'dark' : 'light'} theme`}
          title={`Switch to ${isLight ? 'dark' : 'light'} theme`}
        >
          {isLight ? <Moon size={16} /> : <Sun size={16} />}
          <span>{isLight ? 'Night' : 'Day'} mode</span>
        </button>
      </header>

      <section className="animated-lock__layout" aria-labelledby="animated-lock-title">
        <aside className="animated-lock__sanctuary" aria-label="Vault security">
          <div className="animated-lock__seal" aria-hidden="true">
            <span className="animated-lock__seal-orbit animated-lock__seal-orbit--outer" />
            <span className="animated-lock__seal-orbit animated-lock__seal-orbit--middle" />
            <span className="animated-lock__seal-orbit animated-lock__seal-orbit--inner" />
            <span className="animated-lock__seal-core">
              <LockKeyhole size={28} strokeWidth={1.45} />
            </span>
            <span className="animated-lock__seal-spark animated-lock__seal-spark--a" />
            <span className="animated-lock__seal-spark animated-lock__seal-spark--b" />
          </div>
          <div className="animated-lock__sanctuary-copy">
            <span className="animated-lock__overline"><span /> Private by design</span>
            <p>Your keys stay<br />close to home.</p>
            <span className="animated-lock__device-note">Encrypted on this device</span>
          </div>
          <div className="animated-lock__side-rule" aria-hidden="true" />
        </aside>

        <div className="animated-lock__form-panel">
          <div className="animated-lock__eyebrow">
            <span className="animated-lock__status-dot" />
            Your vault is locked
          </div>
          <h1 id="animated-lock-title">Welcome back.</h1>
          <p className="animated-lock__intro">Enter your master password to decrypt your vault on this device.</p>

          <form onSubmit={handleSubmit}>
            <div className="animated-lock__field-block">
              <label className="animated-lock__label" htmlFor="animated-master-password">
                Master password
              </label>
              <div className="animated-lock__field-frame">
                <input
                  id="animated-master-password"
                  className="animated-lock__input"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  aria-describedby="password-hint"
                />
                <button
                  className="animated-lock__reveal"
                  aria-label={showPassword ? 'Hide master password' : 'Show master password'}
                  type="button"
                  onClick={() => setShowPassword((current) => !current)}
                >
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
              <span className="animated-lock__field-hint" id="password-hint">Only used here, on this device.</span>
            </div>
            <button className="animated-lock__unlock" type="submit">
              <LockKeyhole size={16} strokeWidth={1.8} />
              <span>Unlock vault</span>
              <span className="animated-lock__button-arrow" aria-hidden="true">↗</span>
            </button>
            <p className="animated-lock__preview-message" role="status" aria-live="polite">
              {previewMessage}
            </p>
          </form>

          <div className="animated-lock__warning" role="note">
            <span className="animated-lock__warning-icon"><ShieldAlert size={17} strokeWidth={1.8} /></span>
            <p><strong>No recovery option.</strong> Your master password is never stored. If you forget it, this vault cannot be recovered.</p>
          </div>
        </div>
      </section>

      <footer className="animated-lock__footer">
        <span className="animated-lock__footer-line" />
        <span>LOCAL FIRST <i aria-hidden="true">·</i> PRIVATE ALWAYS</span>
        <span className="animated-lock__footer-line" />
      </footer>
    </main>
  );
}
