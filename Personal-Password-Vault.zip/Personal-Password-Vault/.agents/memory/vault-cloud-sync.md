---
name: Vault persistence and cloud sync
description: The product requirement to preserve existing vault data while enabling sign-in and cross-device synchronization.
---

My Vault must support sign-in and cloud sync so users can keep their vault data across sessions and devices. Existing local vault data must remain recoverable during account setup and migration.

**Why:** the user explicitly requested signup, cloud sync, and data preservation after encountering a vault that was only stored in one browser.

**How to apply:** keep the existing encrypted local envelope intact, sync encrypted vault data, and prevent account setup or a stale device from silently replacing another copy.
